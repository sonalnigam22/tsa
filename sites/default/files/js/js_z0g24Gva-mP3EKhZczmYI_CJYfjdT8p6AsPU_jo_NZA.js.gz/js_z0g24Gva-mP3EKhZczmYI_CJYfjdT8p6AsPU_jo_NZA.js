/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.theme_tsa_gov = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
;
